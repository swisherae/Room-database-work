package edu.cofc.android.finalproject

import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import edu.cofc.android.finalproject.databinding.ActivityCheckInScreenBinding



class CheckInScreen : AppCompatActivity() {
    private lateinit var binding: ActivityCheckInScreenBinding

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        binding = ActivityCheckInScreenBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        binding.checkInButton.setOnClickListener {
            val checkInTime = binding.editTextCheckIn.text.toString()
            val leaveTime = binding.editTextExpectedLeave.text.toString()

            if (checkInTime.isNotEmpty() && leaveTime.isNotEmpty()) {
                val timeRange = "$checkInTime - $leaveTime"
                binding.displayCheckIn.text = timeRange
            } else {
                Toast.makeText(this, "Please enter both check-in and leave times", Toast.LENGTH_SHORT).show()
            }
        }






    }

}
